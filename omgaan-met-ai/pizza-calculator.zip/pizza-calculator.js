function calculatePizzaPrice() {
    const smallCount = parseInt(document.getElementById('small').value) || 0;
    const mediumCount = parseInt(document.getElementById('medium').value) || 0;
    const largeCount = parseInt(document.getElementById('large').value) || 0;

    const smallPrice = 5.99;
    const mediumPrice = 7.99;
    const largePrice = 9.99;

    const smallTotal = smallCount * smallPrice;
    const mediumTotal = mediumCount * mediumPrice;
    const largeTotal = largeCount * largePrice;
    const totalOrder = smallTotal + mediumTotal + largeTotal;

    document.getElementById('smallOrder').innerText = `Small Pizza (${smallCount}): $${smallTotal.toFixed(2)}`;
    document.getElementById('mediumOrder').innerText = `Medium Pizza (${mediumCount}): $${mediumTotal.toFixed(2)}`;
    document.getElementById('largeOrder').innerText = `Large Pizza (${largeCount}): $${largeTotal.toFixed(2)}`;
    document.getElementById('totalOrder').innerText = `Totaal: $${totalOrder.toFixed(2)}`;

    document.getElementById('orderSummary').style.display = 'block';
}
